
#note run both commands on two different instances of terminal

#start kafka zookeper
./run-kafka_zookeeper_server.sh -s start

# start kafka server
./run-kafka_server.sh -s start



#




